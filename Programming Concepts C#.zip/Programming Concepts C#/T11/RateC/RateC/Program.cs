﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RateC
{
    class Program
    {
        static void Main(string[] args)
        {
            
                int[] Number = new int[11];
                int InNum = 0;
                while (InNum != -1)
                {
                    Console.WriteLine("enter a rateing from 0-10");
                    InNum = Input();
                    if (InNum != -1)
                    {     
                        Number[InNum]++;
                    }
                }

                double Average = average(Number);
                outPutAverage(Average);
                Output(Number);
                
            }

           
        
            //output

            static void Output(int[] Number)
            {
                Console.WriteLine("----------------");
                Console.WriteLine("Rateing:Quantity");
                for (int i = 0; i < 11; i++)
                {
                    Console.WriteLine("----------------");
                    Console.WriteLine("{0}     :    {1}",i,Number[i]);
                }

                Console.WriteLine("----------------");
                Console.ReadLine();
            }

            static int Input()
            {
                int number;
                int[] Testrange = new int[12];
                while (true)
                {
                    try
                    {
                        number = int.Parse(Console.ReadLine());
                        number++;
                        Testrange[number] = 1;
                        number--;
                        return number;
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Enter a number!");
                        Console.WriteLine("enter a rateing from 0-10");
                    }
                    catch (IndexOutOfRangeException)
                    {
                        Console.WriteLine("Not in range!");
                        Console.WriteLine("enter a rateing from 0-10");
                    }

                }
            }

            static double average(int[] number)
            {
                int total = 0;
                int sum = 0;
                //total
                for(int i = 0; i < number.Length; i++)
                {
                    total = total + number[i];
                    
                }
                

                for (int i = 0; i < number.Length; i++)
                {
                    sum = sum + (number[i] * i);              
                }
                try
                {
                    double Average = sum / total;
                    return Average;
                }
                catch (DivideByZeroException)
                {
                    return 0;
                }
            }

            static void outPutAverage(double average)
            {
                Console.WriteLine("-------------------");
                Console.WriteLine("Average rateing is: {0}",average);
                Console.WriteLine("-------------------");
            }


        }
    
}

