﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace EnrolStudent
{
    public partial class Form1 : Form
    {
        private List<Student> students = new List<Student>();
        private List<Course> courses = new List<Course>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            students.Add(new Student("Andy", "Wyatt"));
            students.Add(new Student("Dave", " Newbold"));
            students.Add(new Student("Daniel", "Brown"));
            courses.Add(new Course("BSc(Hons) Applied Computing"));
            courses.Add(new Course("(HND)Applied Computing"));
            courses.Add(new Course("Computer Science Part Time (MSc)"));
            foreach (Course c in courses)
            { lstCourse.Items.Add(c); }
            foreach (Student st in students)
            //{ lstStudentsOnCourse.Items.Add(st); }
            { cboStudent.Items.Add(st);  }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Course selectedCourse = (Course)lstCourse.SelectedItem;
            Student selectedStudent = (Student)cboStudent.SelectedItem;
            if (selectedStudent != null)
            {


                selectedCourse.addStudent(selectedStudent);
                lstStudentsOnCourse.Items.Clear();

                lstStudentsOnCourse.Items.AddRange
                    (selectedCourse.EnrolledStudents.ToArray());
                btnAdd.Enabled = false;
            }
        }

        private void lstCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            Course selectedCourse = (Course)lstCourse.SelectedItem;
            if (selectedCourse != null)
            {
                lstStudentsOnCourse.Items.Clear();

                lstStudentsOnCourse.Items.AddRange(selectedCourse.EnrolledStudents.ToArray());

                lstStudentsOnCourse.Enabled = true;
                btnAdd.Enabled = true;
            }
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            Course selectedCourse = (Course)lstCourse.SelectedItem;
            Student selectedStudent = (Student)lstStudentsOnCourse.SelectedItem;

            selectedCourse.removeStudent(selectedStudent);
            lstStudentsOnCourse.Items.Clear();

            lstStudentsOnCourse.Items.AddRange
                (selectedCourse.EnrolledStudents.ToArray());
            
        }

        private void cboStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
        }


    }
}
