﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnrolStudent
{
    class Student
    {
        private static int studentIdSeed = 3000000;
        
        //atributes 
        public string Forename
        { get; set; }
        public int StudentId
        { get; set; }
        public string Surname
        { get; set; }

        public Student(string forename, string surname)
        {
            StudentId = studentIdSeed++;
            Forename = forename; 
            Surname = surname;
        }

        public static int getNextId()
        {
            return studentIdSeed;
        }

        public override string ToString()
        {
            return string.Format("({0}){1} , {2}",StudentId,Forename,Surname);
        }
    }
}
