﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace EnrolStudent
{
    class Class
    {
        private List<Student> enrolledStudents = new List<Student>();
        public string Name
        { get; set; }

        public void Course(string name)
        {
            Name = name;
        }

        public List<Student> EnrolledStudents
        {
            get
            {
                return enrolledStudents;
            }
        }

        public void addStudent(Student student)
        {
            if(!enrolledStudents.Contains(student))
            {
                enrolledStudents.Add(student);
            }
        }

        public void removeStudent(Student student)
        {
            if(enrolledStudents.Contains(student))
            {
                enrolledStudents.Remove(student);
            }
        }

        public override string ToString()
        {
            return Name;
        }

    }
}
