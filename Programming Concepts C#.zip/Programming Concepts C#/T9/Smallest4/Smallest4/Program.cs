﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smallest4
{
    class Program
    {
        static void Main(string[] args)
        {
            int Small = 100000;
            Console.WriteLine("Enter 4 numbers");
            int Num = int.Parse(Console.ReadLine());
            Small = Smaller(Small,Num);
            Num = int.Parse(Console.ReadLine());
            Small = Smaller(Small,Num);
            Num = int.Parse(Console.ReadLine());
            Small = Smaller(Small,Num);
            Num = int.Parse(Console.ReadLine());
            Small = Smaller(Small,Num);
            Console.WriteLine("The smalles number is {0}", Small);
            Console.ReadLine();
        }

        static int Smaller(int Small, int Num)
        {
            if (Small > Num) { Small = Num; };
            return Small;
        }
    }
}
