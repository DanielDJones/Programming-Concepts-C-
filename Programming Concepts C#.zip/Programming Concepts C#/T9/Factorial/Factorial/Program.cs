﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number greater than 1");

            int Number = int.Parse(Console.ReadLine());
            if (Number <= 1) { Error(); }
            else
            {
                Number = Factorial(Number);
                Console.WriteLine("The total is{0}", Number);
                Console.ReadLine();
            }

        }

        static void Error()
        {
            Console.WriteLine("Error! Invalid input");
            Console.ReadLine();
        }
        static int Factorial(int Number)
        {
            int total = Number;
            for (int i = 1; i < Number; i++)
            {
                Console.Write("{0} x ", Number);
                total = total * i;
                Console.WriteLine("TotalDbug: {0}", total);
                
            } 
            return total;
        }
        
    }
}
