﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMICalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            int Height = HeightInInches();
            int Weight = WeightInPounds();
            outputBMI(Height, Weight);
        }

        static int HeightInInches()
        {
            Console.WriteLine("Enter Height in Feet 2-7");
            int Feet = int.Parse(Console.ReadLine());
            for (int i = Feet; i < 2 || i > 7; )
            {
                Console.WriteLine("Error! Enter Height in Feet 2-7");
                Feet = int.Parse(Console.ReadLine());
                i = Feet;
            }
            Console.WriteLine("Enter Height in Inches 0-11");
            int Inches = int.Parse(Console.ReadLine());  
            for  (int i = Inches; i < 0 || i > 11; ) 
            {
                Console.WriteLine("Error! Enter Height in Inches 0-11");
                Inches = int.Parse(Console.ReadLine());
                i = Inches;
            }
            return (Feet*12) + Inches;
        }

        static int WeightInPounds()
        {
            Console.WriteLine("Enter Weight in Stone 3-30");
            int Stone = int.Parse(Console.ReadLine());
            for (int i = Stone; i < 3 || i > 30; )
            {
                Console.WriteLine("Error! Enter Weight in Stone 3-30");
                Stone = int.Parse(Console.ReadLine());
                i = Stone;
            }
            Console.WriteLine("Enter Weight in Pounds 0-13");
            int Pounds = int.Parse(Console.ReadLine());
            for (int i = Pounds; i < 0 || i > 13; )
            {
                Console.WriteLine("Error! Enter Weight in Pounds 0-13");
                Pounds = int.Parse(Console.ReadLine());
                i = Pounds;
            }
            return (Stone * 14) + Pounds;
        }

        static void outputBMI(int Height, int Weight)
        {
            int BMI = (Weight * 703) / (Height * Height);
            Console.WriteLine("Your BMI is {0}", BMI);
            Console.ReadLine();
        }
    }
}
