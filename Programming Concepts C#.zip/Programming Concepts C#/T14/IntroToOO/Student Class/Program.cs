﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Student a = new Student("ag123456");
            Student b = new Student("wc223344","Winston");

            a.Name = "Alexander";
            a.DateOfBirth = "20 July 356";
            b.DateOfBirth = "30 Nov 1874";
            a.Email = "a.g@great.gr";
            b.Email = "w.c@bt.com";
            a.TelNumber = "3141592653";
            b.TelNumber = "018118055";

            Console.WriteLine("");
            Console.WriteLine("{0}", a.ToString());
            Console.WriteLine("");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("");
            Console.WriteLine("{0}", b.ToString());
            Console.ReadLine();
        }
    }
}
