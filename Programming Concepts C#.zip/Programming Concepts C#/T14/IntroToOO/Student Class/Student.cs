﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Class
{
    class Student
    {
        //atributes
        private string studentrefernce;
        private string name;
        private string dateofbirth;
        private string email;
        private string telnumber;

        //Constructors

        public Student(string studentrefernce)
        {
            this.studentrefernce = studentrefernce;
        }

        public Student(string studentrefernce, string name)
        {
            this.studentrefernce = studentrefernce;
            this.name = name;
        }

        //Properties
        #region "Properties"
        public string Name
        {
            get
            { return name; }
            set
            { name = value; }
        }
        public string DateOfBirth
        {
            get
            { return dateofbirth; }
            set
            { dateofbirth = value; }
        }
        public string Email
        {
            get
            { return email; }
            set
            { email = value; }
        }
        public string TelNumber
        {
            get
            { return telnumber; }
            set
            { telnumber = value; }
        }
        #endregion
        public override string ToString()
        {
            return " Student reference: " + this.studentrefernce + "\n Name: " + this.name + "\n DateOfBirth " + this.dateofbirth + "\n Email: " + this.email + "\n TelNumber: " + this.telnumber;

        }
    }
}
