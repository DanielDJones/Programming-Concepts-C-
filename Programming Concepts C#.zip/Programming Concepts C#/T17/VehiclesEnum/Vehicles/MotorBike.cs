﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    class MotorBike : MotorVehicle
    {
        public enum SwingType {Fork,Cantilever}
        public SwingType TypeOfSwing
        { get; set; }

        public MotorBike(string colour, int engineSize, string swingType)
        {
            Colour = colour;
            EngineSize = engineSize;
            TypeOfSwing = SwingType.Fork;
        }

        public override string ToString()
        {
            return "MotorBike: \n Colour: " + Colour + "\n Engine CC: " + EngineSize + "\n Swing Type:" + TypeOfSwing;
        }
    }
}
