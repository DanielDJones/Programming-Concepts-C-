﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vehicles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Bicycle b1 = new Bicycle(true, "Red", 6);
            Bicycle b2 = new Bicycle(false, "blue", 7);
            MotorBike mb1 = new MotorBike("Yellow", 750, "Fork");
            Car c1 = new Car("Cyan", 850, 5);
            lblOutput.Text = b1.ToString();
            lblOutput.Text += "\n \n " + b2.ToString();
            lblOutput.Text += "\n \n " + mb1.ToString();
            lblOutput.Text += "\n \n " + c1.ToString();
            int total = Vehicle.GetCount();
            lblOutput.Text += "\n \n " + "Total of vehicles:" + total;

        }
    }
}
