﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    class Car :  MotorVehicle
    {
        public int NumberOfDoors
        { get; set; }

        public Car(string colour, int engineSize, int noOfDoors)
        {
            Colour = colour;
            EngineSize = engineSize;
            NumberOfDoors = noOfDoors;
        }

        public override string ToString()
        {
            return "Car: \n" + "Colour: \n" + Colour + "Engine cc: \n" + EngineSize + "Doors:" + NumberOfDoors;
        }
    }
}
