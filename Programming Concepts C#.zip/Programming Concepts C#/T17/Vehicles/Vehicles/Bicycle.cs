﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    class Bicycle : Vehicle
    {
        public int Gears
        { get; set; }

        public bool Bell
        { get; set; }

        public  Bicycle(bool bell,string colour,int gears)
        {
            Bell = bell;
            Colour = colour;
            Gears = gears;
        }

        public override string ToString()
        {
           if (Bell == true)
           {
               return "Bicycle: \n" + "Colour: " + Colour + "\n No of Gears:" + Gears + "\n Has a bell";
           }
           else
           {
               return "Bicycle: \n" + "Colour: " + Colour + "\n No of Gears:" + Gears + "\n Dose not have a bell";
           }
        }


    }
}
