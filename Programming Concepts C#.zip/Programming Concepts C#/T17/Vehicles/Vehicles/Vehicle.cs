﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    abstract class Vehicle
    {
        private static int count = 0;

        public static string Colour
        { get; set; }

        public Vehicle()
        {
            Colour = "no colour given";
            count++;
        }

        public static int GetCount()
        {
            return count;
        }

        
    }
}
