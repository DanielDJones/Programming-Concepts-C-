﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    class MotorBike : MotorVehicle
    {
        public string SwingType
        { get; set; }

        public MotorBike(string colour, int engineSize, string swingType)
        {
            Colour = colour;
            EngineSize = engineSize;
            SwingType = swingType;
        }

        public override string ToString()
        {
            return "MotorBike: \n Colour: " + Colour + "\n Engine CC: " + EngineSize + "\n Swing Type:" + SwingType;
        }
    }
}
