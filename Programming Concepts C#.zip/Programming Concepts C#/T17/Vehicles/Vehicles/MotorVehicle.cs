﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    abstract class MotorVehicle : Vehicle
    {
        public int EngineSize
        { get; set; }

        public MotorVehicle()
        {
            EngineSize = 100;
        }
    }
}
