﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CustomerForm
{
    class Customer
    {
        private string name = "No name given";
        private string customer_reference;
        private static int count = 0; //static makes the variable apply to the whole class or it
        private static int next_customer_reference = 10000;
       

        public Customer(string name)
        {
            this.customer_reference = "UK" + next_customer_reference++;
            this.name = name;
            count++;
        }

        public static int getCount()
        { return count; }
        
        #region "Properties"
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        #endregion
        public static string getNextCustomerRef()
        { return "UK" + next_customer_reference; }

        
        public override string ToString()
        {
            return "Reference: " + this.customer_reference + Environment.NewLine + "Name: " + this.name + Environment.NewLine; //This is responsible for the output
        }
    }
}
