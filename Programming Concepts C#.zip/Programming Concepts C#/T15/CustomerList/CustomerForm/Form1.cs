﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections; //System collection allow ArrayList to work

namespace CustomerForm
{
    public partial class Form1 : Form
    {
        ArrayList Customers = new ArrayList();

        public Form1()
        {
            InitializeComponent();
            txtRefNum.Text = Customer.getNextCustomerRef(); //setsup the 1st refrance number
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtname.Text == string.Empty) //Displays a text box if there is no name enterd
            {
                MessageBox.Show("You have not entered a name", "No name entered");
                txtname.Focus();
                return;
            }
            else 
            {
                txtCustList.Text = ""; //clears the output so there is no repeat of data
                Customers.Add(new Customer(txtname.Text)); //sets up the cust object and adds it to the array

                foreach (Customer cust in Customers) //repeats for all items in the ArrayList
                {
                    txtCustList.Text += Environment.NewLine + cust.ToString(); //Adds the output of the ToString(); (in the class) method into the output
                }

                txtCustList.Text += Environment.NewLine + "Number of Customers: " + Customer.getCount().ToString(); //outputs number of customers
                txtname.Clear();
                txtname.Focus();
                txtRefNum.Text = Customer.getNextCustomerRef(); //Sets the next customer ref into the top textbox
            }
        }

        private void txtRefNum_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
