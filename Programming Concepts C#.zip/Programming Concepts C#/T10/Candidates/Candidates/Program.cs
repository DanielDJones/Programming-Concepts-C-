﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Candidates
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("0 Ahmed, 1 Boo, 2 Celine, 3 Didi, 4 Elaine");
            int[] NumOfVotes = new int[5];
            string[] data = { "Ahmed", "Boo", "Celine", "Didi", "Elaine"};
            NumOfVotes = input(NumOfVotes);
            sort(NumOfVotes, data);
           
            Console.ReadLine();
        }

        static int[] input(int[] arr)
        {
            Console.WriteLine("Who do you want to vote for, 0-4: ");
            
            int InNum = 0;
            while (InNum > -1)
            {
                InNum = int.Parse(Console.ReadLine());
                if (InNum > 4)
                {
                    Console.WriteLine("Error! Not a number between 0-4");
                }

                else if (InNum == -1)
                {
                    Console.WriteLine("voteing has closed");
                }

                else if (InNum < -1)
                {
                    Console.WriteLine("Error! Not a number between 0-4");
                }

                else
                {
                    arr[InNum]++;
                }
            }
            return arr;
        }

        static void sort(int[] arr, string[] data)
        {
            for (int pass = 1; pass < arr.Length; pass++)
            {
                int SmallestPos = findSmallest(arr, arr.Length - pass);
                if (SmallestPos != arr.Length - pass)
                {
                    swap(arr, SmallestPos, arr.Length - pass);
                    swapName(data, SmallestPos, data.Length - pass);
                }

                
            }

            Output(arr, data);
        }

        static int findSmallest(int [] arr, int num)
        {
            int SmallestPos = 0;
            for (int i = 1; i <= num; i++)
            {
                if (arr[i] < arr[SmallestPos])
                {
                    SmallestPos = i;
                }
            }
            return SmallestPos;
        }

        public static void swap(int[] arr, int first, int second)
        {
            int temp = arr[first];
            arr[first] = arr[second];
            arr[second] = temp;
            
        }

        public static void swapName(string[] arr, int first, int second)
        {
            string temp = arr[first];
            arr[first] = arr[second];
            arr[second] = temp;
        }

        public static void Output(int[] arr, string[] name)
        {
            Console.WriteLine("3rd palce : {0}", name[2]);
            Console.WriteLine("Results");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write("{0} : ",name[i]);
                Console.WriteLine("{0}",arr[i]);
            }

            Console.WriteLine("3rd palce : {0}", name[2]);
            Console.WriteLine("2nd palce : {0}", name[1]);
            Console.WriteLine("1st palce : {0}", name[0]);
        }
        
    }
}
