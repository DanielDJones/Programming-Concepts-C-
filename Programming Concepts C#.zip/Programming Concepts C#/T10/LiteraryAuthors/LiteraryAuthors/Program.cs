﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LiteraryAuthors
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter author name to search for:");
            string item = Console.ReadLine();

            string[] data = {"William Shakespeare", "Mark Twain", "Jane Austin", "Charlotte Bronte", "Louisa May Alcott", "Lewis Carroll", "D.H. Lawrance", "Charles Dickens", "Lucy Maud Montgomery", "Alexander Dumas"};
            int location = UnsortedSearch(data, item);

            if (location == -1)
            {
                Console.WriteLine("Author Not Found");
            }
            else
            {
                location++;
                Console.WriteLine("The Autor {0} was found at location {1}", item, location);
            }

            Console.ReadLine();
        }

        static int UnsortedSearch(string[] data, string item)
        {
            int location = 0;
            while (location < data.Length && !String.Equals(item, data[location], StringComparison.OrdinalIgnoreCase))
            {
                location++;
            }

            if (location == data.Length)
            {
                location = -1;
            }
            return location;

        }
    }
}
