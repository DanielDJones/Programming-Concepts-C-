﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidatePercent
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a % between 0-100%");
            int Input = int.Parse(Console.ReadLine());

            while (Input < 0 || Input > 100 ) //Check the input is not valid
            {//Ask for another number
                Console.WriteLine("---------------------------");
                Console.WriteLine("Invalid %, renter:");
                Input = int.Parse(Console.ReadLine());
            }//output
            Console.WriteLine("---------------------------");
            Console.WriteLine("Your % is {0}", Input);
            Console.ReadLine();
        }
    }
}
