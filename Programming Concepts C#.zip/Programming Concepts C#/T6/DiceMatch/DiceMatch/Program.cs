﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiceMatch
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random(); //Create a random number
            int dice1, dice2, Not; //set up varialbes
            dice1 = 0;
            dice2 = 1;
            Not = 0;
            

            while (dice1 != dice2) //while the dice dose not match 
            {
                dice1 = random.Next(1, 7); //make a random number from 1-6 
                dice2 = random.Next(1, 7);
                Console.Write("{0} | {1}", dice1, dice2); 
                Console.WriteLine("");
                Not ++; //incriment the next variable by one 

            }

            Console.WriteLine("----------------");
            Console.WriteLine("Number of rolls: {0}", Not);
            
            Console.ReadLine();



        }
    }
}
