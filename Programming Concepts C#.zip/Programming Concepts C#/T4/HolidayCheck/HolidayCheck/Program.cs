﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HolidayCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            int stayD;
            int numOfGuests;
            bool Valid = true;
            string error = "Error";
            Console.WriteLine("How long will you be staying with us 2, 7 or 14 days?:");
            if (!int.TryParse(Console.ReadLine(), out stayD)) 
            {
                error += "enter enter 2, 7 or 14 || ";
                Valid = false;
            }

            if (stayD == 2 || stayD == 7 || stayD == 14) 
            {
                
            }

            else
            {
                error += "enter enter 2, 7 or 14 || ";
                Valid = false;
                
            }

            Console.WriteLine("Enter number of guests:");
            if (!int.TryParse(Console.ReadLine(), out numOfGuests))
            {
                error += " Please enter a valid number of guests ";
                Valid = false;
            }
            Console.WriteLine("Enter Type of board(full, half or self-catering || ):");
            string type = Console.ReadLine();

            if (type.Equals("full", StringComparison.OrdinalIgnoreCase) || type.Equals("half", StringComparison.OrdinalIgnoreCase) || type.Equals("self-catering", StringComparison.OrdinalIgnoreCase))
            {
                
            }
            else
            {
                error += "please enter a correct type: Full, Half or self-catering || ";
                Valid = false;
            }

            if (Valid == false)
            {
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine(" ");
                Console.WriteLine("There was an error!");
                Console.WriteLine(" ");
                Console.WriteLine("{0}", error);
                Console.WriteLine(" ");
                Console.WriteLine("-------------------------------------------------");
            }

            else
            {
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine(" ");
                Console.WriteLine("Valid details entered - booking may proceed");
                Console.WriteLine(" ");
                Console.WriteLine("-------------------------------------------------");
            }

            Console.ReadLine();


        }
    }
}
