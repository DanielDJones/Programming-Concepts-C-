﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
            int postType;

            Console.WriteLine("Enter a number from 1-4 depending on the type of letter"); //Display text
            Console.WriteLine("1) Bills");
            Console.WriteLine("2) Circulars");
            Console.WriteLine("3) Postcards");
            Console.WriteLine("4) Personal letters");

            if (!int.TryParse(Console.ReadLine(), out postType)) //check wehater it can be converted to and int(whole number in string) 
            {//Output
                Console.WriteLine("=============================================================");
                Console.WriteLine("Error enter a number between 1-4");
                Console.WriteLine("=============================================================");
                Console.ReadLine();
            }

            else
            {
                switch (postType) //Jump the program to the corrisponding case 
                {
                    case 1:
                        Console.WriteLine("-------------------------------------------------------------");
                        Console.WriteLine("Bills must be paid");
                        Console.WriteLine("-------------------------------------------------------------");
                        break; //ends the switch

                    case 2:
                        Console.WriteLine("-------------------------------------------------------------");
                        Console.WriteLine("Circulars are thrown away");
                        Console.WriteLine("-------------------------------------------------------------");
                        break;
                    case 3:
                        Console.WriteLine("-------------------------------------------------------------");
                        Console.WriteLine("Postcards are put on the wall");
                        Console.WriteLine("-------------------------------------------------------------");
                        break;
                    case 4:
                        Console.WriteLine("-------------------------------------------------------------");
                        Console.WriteLine("Personal letters are read and have replies written for them");
                        Console.WriteLine("-------------------------------------------------------------");
                        break;
                    default:
                        Console.WriteLine("=============================================================");
                        Console.WriteLine("Error enter a number between 1 and 4");
                        Console.WriteLine("=============================================================");
                        break;
                }

                Console.ReadLine();

            }

                    
            }

        }
    }
