﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grade
{
    class Program
    {
        static void Main(string[] args)
        {
            

            string Grade = Console.ReadLine();
            //Check for a valid input 
            if (Grade == "A" || Grade == "a" || Grade == "B" || Grade == "b" || Grade == "C" || Grade == "c" || Grade == "D" || Grade == "d" || Grade == "E" || Grade == "e")
            {
                if(Grade == "a" || Grade == "A") //if the grade is a or A
                {
                    Console.WriteLine("--------");// Dispaly text
                    Console.WriteLine("70-100%");
                    Console.WriteLine("--------");
                }

                else if (Grade == "b" || Grade == "B")//if the grade is b or B
                {
                    Console.WriteLine("----");
                    Console.WriteLine("60-69%");
                    Console.WriteLine("----");
                }

                else if(Grade == "c" || Grade == "C")
                {
                    Console.WriteLine("----");
                    Console.WriteLine("50-59%");
                    Console.WriteLine("----");
                }
                else if(Grade == "d" || Grade == "D")
                {
                    Console.WriteLine("----");
                    Console.WriteLine("40-49%");
                    Console.WriteLine("----");
                }
                else //if grade is e
                {
                    Console.WriteLine("----");
                    Console.WriteLine("0-39%");
                    Console.WriteLine("----");
                }

                Console.ReadLine();
                }
            else { //error detection not a valid input 
                Console.WriteLine("Error! Enter a grade A-E");
                Console.ReadLine();
            }
            }
        }
    }


