﻿//program to calculate average of 3 integers
using System;

namespace Average
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 3 integers:");//Output text

            int num1 = int.Parse(Console.ReadLine()); //Input number and convert to an integer from a string (int.Parse)
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());

            double ave = (num1 + num2 + num3) / 3; // Calculate the average

            Console.WriteLine("The average of {0}, {1} and {2} is {3}", //Output the numbers  and text the {0} holds the variableand the , lists them
                num1, num2, num3, ave);

            Console.ReadLine(); //Keeps the program open
        }
    }
}


