﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cubiod
{
    class Program
    {
        static void Main(string[] args)
        {

             

        //input data 
             Console.Write("Enter width of cubiod: "); // displays line of text
             int width = int.Parse(Console.ReadLine()); // inputs line of text as an int called width

             Console.Write("Enter the height of the cubiod: ");// displays line of tex
             int height = int.Parse(Console.ReadLine());// inputs line of text as an int called height

             Console.Write("Enter length of cubiod: ");// displays line of tex
             int length = int.Parse(Console.ReadLine());// inputs line of text as an int called length

             int volume = width * length * height; //calculates the volume and stores it into volume
             int sufa = (width * height) * 2 + (width * length) * 2 + (height * length)*2 ; //calculates the surface area and stores it in sufa
            // Display
             Console.WriteLine("-------------------------");//Outputs the data
             Console.WriteLine("Volume: {0}", volume); // the {0} indicate whate variable will be added onto the porgram strating form 0 for the 1st. All string come before the volume (the  0 acts as a placeholder of sorts)
             Console.WriteLine("-------------------------");
             Console.WriteLine("surfacearea: {0}", sufa);
             Console.WriteLine("-------------------------");
             Console.ReadLine();


            



        }
    }
}
