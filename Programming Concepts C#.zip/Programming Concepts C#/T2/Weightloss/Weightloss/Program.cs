﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weightloss
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("How long did you spend Cycleing (min): "); //Dispalys text
            int BikeT = int.Parse(Console.ReadLine());//Input the data for Bike time 
            Console.Write("How long did you spend Running (min): ");//Dispalys text
            int RunT = int.Parse(Console.ReadLine());//Input the data for Run time
            Console.Write("How long did you spend Swiming (min): ");//Dispalys text
            int SwimT = int.Parse(Console.ReadLine());//Input the data for Swim time 

            //Process
            //Time
            double BikeTH = BikeT / 60; //Works out the time spent in hours
            BikeTH = Math.Floor(BikeTH); //rounds time spent down
            double BikeTM = BikeT-(BikeTH * 60); //Calcuales the time spent in min 

            double RunTH = RunT / 60;//Works out the time spent in hours
            RunTH = Math.Floor(RunTH);//rounds time spent down
            double RunTM = RunT - (RunTH * 60);//Calcuales the time spent in min 

            double SwimTH = SwimT / 60;//Works out the time spent in hours
            SwimTH = Math.Floor(SwimTH);//rounds time spent down
            double SwimTM = SwimT - (SwimTH * 60);//Calcuales the time spent in min 

            //Burnt calories
            //Setup Can change these numbers 
            int BurnHourB = 200; //These variable allow the programmer to change the numbers in one change if new data for calories burnt is supplyed
            int BurnHourR = 475;
            int BurnHourS = 275;
            //Calc for per min
            double BurnMinB = BurnHourB / 60; //Work out how many cal are bunt a min
            double BurnMinR = BurnHourR / 60; //Work out how many cal are bunt a min
            double BurnMinS = BurnHourS / 60; //Work out how many cal are bunt a min
            //Cal burnt
            double BikeBrn = BikeT * BurnMinB; //Work out how many cal have actually been burnt
            double RunBrn = RunT * BurnMinR; //Work out how many cal have actually been burnt
            double SwimBrn = SwimT * BurnMinS; //Work out how many cal have actually been burnt

            //Weight Lossed
            double WeiLB = BikeBrn / 3500; // Calculate weight lost
            WeiLB = Math.Round(WeiLB, 2); // Round the number to 2 decimal places 
            double WeiLR = RunBrn / 3500;
            WeiLR = Math.Round(WeiLR, 2);
            double WeiLS = SwimBrn / 3500;
            WeiLS = Math.Round(WeiLS, 2);



            //Output
            Console.WriteLine(" ");
            Console.WriteLine("| Activity  | Time Spent               | Calories burnt        | Pounds lost           |");
            Console.WriteLine("|-----------|--------------------------|-----------------------|-----------------------|");
            Console.WriteLine("| Cycleing: | Time: {0,5}Hours {1,5}Min|  {2,5} Calories Burnt | {3,5} Poundslost      |", BikeTH, BikeTM, BikeBrn,WeiLB); // the {1,1} second number reserves space
            Console.WriteLine("|-----------|--------------------------|-----------------------|-----------------------|");
            Console.WriteLine("| Running:  | Time: {0,5}Hours {1,5}Min|  {2,5} Calories Burnt | {3,5} Poundslost      |", RunTH, RunTM, RunBrn, WeiLR);
            Console.WriteLine("|-----------|--------------------------|-----------------------|-----------------------|");
            Console.WriteLine("| Swiming:  | Time: {0,5}Hours {1,5}Min|  {2,5} Calories Burnt | {3,5} Poundslost      |", SwimTH, SwimTM, SwimBrn,WeiLS);
            Console.WriteLine("|-----------|--------------------------|-----------------------|-----------------------|");
            Console.ReadLine();

            


        }
    }
}
