﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sweets
{
    class Program
    {
        static void Main(string[] args)
        {
            //input data 
            Console.Write("Enter Number Of Sweets: "); //Displays text 
            int SweetN = int.Parse(Console.ReadLine());//input a string and convert to number, then store in hte SweetN number

            Console.Write("Enter Number Of Kids: ");//Displays text
            int KidN = int.Parse(Console.ReadLine()); //input a string and convert to number, then store in hte KidN number

            //Process
            double SwPerKC = SweetN / KidN; //Divides the sweets between the number of kids
            double SwPerK = Math.Floor(SwPerKC); // Rounds the variable SwPerKC down
            double leftovers = SweetN - (KidN * SwPerK); // Calculates the leftovers

            //Output
            Console.WriteLine("-------------------------");//Output 
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("-------------------------");
            Console.WriteLine(" ");
            Console.WriteLine("  Sweets per kid: {0}", SwPerK);
            Console.WriteLine("-------------------------");
            Console.WriteLine("  Leftovers: {0}", leftovers);
            Console.WriteLine(" ");
            Console.WriteLine("-------------------------");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<");
            Console.WriteLine("-------------------------");
            
            Console.ReadLine();

            
        }
    }
}
