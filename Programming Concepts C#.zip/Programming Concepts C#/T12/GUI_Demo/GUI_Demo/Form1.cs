﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace GUI_Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter students = new StreamWriter("students.txt", true);
                students.WriteLine(txtName.Text);
                students.Close();
                txtName.Clear();
                txtName.Focus();
            }
            catch (System.IO.FileNotFoundException)
            {    Console.WriteLine("File not found");   }
            catch (System.IO.IOException ioe)
            {    Console.WriteLine(ioe.ToString());      }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }


    }
}
