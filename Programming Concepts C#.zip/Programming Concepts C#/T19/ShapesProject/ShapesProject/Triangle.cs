﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesProject
{
    class Triangle:Shape
    {
        public double Bottom { get; set; }
        public double Height { get; set; }

        public Triangle(double bottom, double height)
        {
            Bottom = bottom;
            Height = height;
        }

        public override double GetArea
        {
            get { return (Bottom * Height) / 2; }
        }

        public override string ToString()
        {
            return "Triangle: " + GetArea + "\r\n";
        }
    }
}
