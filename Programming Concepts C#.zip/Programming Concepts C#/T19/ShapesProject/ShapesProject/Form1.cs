﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShapesProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            List<Shape> shapes = new List<Shape>();
            
            shapes.Add(new Circle(15));
            shapes.Add(new Rectangle(10, 5));
            shapes.Add(new Triangle(10, 5));
            foreach (Shape s in shapes)
            {
                txtOutput.Text += s.ToString() + "\r\n";
                
            }

        }
    }
}
