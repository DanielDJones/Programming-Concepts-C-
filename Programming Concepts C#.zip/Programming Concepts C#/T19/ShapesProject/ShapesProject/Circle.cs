﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesProject
{
    class Circle:Shape
    {
        public Circle(double radius)
        {
            Radius = radius;
        }

        public double Radius { get; set; }

        public override double GetArea
        {
            get { return Math.PI * (Radius * Radius); }
        }

        public override string ToString()
        {
            return "Circle: " + GetArea + "\r\n";
        }
 
    }
}
