﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AboveAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            int NumOfStudents; //variables
            int avarage;
            int total = 0;

            Console.WriteLine("Enter Number of Students"); //Input number fo studnets
            NumOfStudents = int.Parse(Console.ReadLine());
            if (NumOfStudents > 0) // Set up and error and stops the program crashing if the number of stundets is 0 or less 
            {

                string[] StudentName = new string[NumOfStudents]; //Create an array = to number of stundets 
                int[] StudentGrade = new int[NumOfStudents];
               

                for (int i = 0; i < NumOfStudents; i++) //loop of once of ever studnent 
                {
                    Console.WriteLine("Write student Name");
                    StudentName[i] = Console.ReadLine();
                    Console.WriteLine("Write student Grade");
                    StudentGrade[i] = int.Parse(Console.ReadLine());
                    total = total + StudentGrade[i]; // Make a runninbg total to work out avaerage
                }

                avarage = total / NumOfStudents; //Work out average
                Console.WriteLine("The avarage grade is: {0}", avarage); //Display average
                Console.WriteLine("The following Students are above average:");

                for (int i = 0; i < NumOfStudents; i++)
                {
                    if (StudentGrade[i] > avarage) //Dispaly all students whos grades where above average 
                    {
                        Console.Write("{0} :", StudentName[i]);
                        Console.Write(" {0}", StudentGrade[i]);
                        Console.WriteLine();
                    }
                }


            }
            else //Display error if there are no studnets 
            {
                Console.WriteLine("error Number Of studnets is below 1");
                
            }

            Console.ReadLine();
        }
    }
}
