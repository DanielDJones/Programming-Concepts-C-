﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseProj
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] InNum = new int[10]; //set up the array of 10 numbers


            for (int i = 0; i < 10; i++) //loop 10 times
            {
                InNum[i] = int.Parse(Console.ReadLine()); //Input 10 times
                
            }
            Console.WriteLine("The reverse Order is:");

            for (int i = 9; i > -1; i--) //loop 10 times
            {
                Console.Write("{0}, ",InNum[i]); //Output 10 times
            }

            Console.ReadLine();
            

        }
    }
}
