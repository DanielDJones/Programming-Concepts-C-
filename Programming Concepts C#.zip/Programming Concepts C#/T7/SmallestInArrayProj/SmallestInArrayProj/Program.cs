﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmallestInArrayProj
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Num = new int[10]; //set up the array of 10 numbers
            int SmNum = 1000000000;
            int pos =0;

            for (int i = 0; i < 10; i++) //loop 10 times
            {
                Num[i] = int.Parse(Console.ReadLine()); //Input 10 times
            }


            for (int i = 0; i < 10; i++) //loop 10 times
            {
                if (Num[i] < SmNum)
                {
                    SmNum = Num[i];
                    pos = i;
                }
                

            }
            pos++;
            Console.WriteLine("The Smallest number is {0}.", SmNum);
            Console.WriteLine("It is the {0} number enterd.", pos);
            Console.ReadLine();

        }
    }
}
