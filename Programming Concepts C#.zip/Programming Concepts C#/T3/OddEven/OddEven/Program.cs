﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OddEven
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter The number: ");
            int StartN = int.Parse(Console.ReadLine());

            int RemN = (StartN % 2); // sets Rem N to the number left oiver for example 3 % 2 will output a 1 so will 5 % 2
            if (RemN != 0) //if the Remainin number dose not equal 1
            {
                Console.WriteLine("-----------------");//Output for odd
                Console.WriteLine("The number is Odd");
                Console.WriteLine("-----------------");
            }
            else
            {
                Console.WriteLine("==================");//output for even
                Console.WriteLine("the number is even");
                Console.WriteLine("==================");
            }

            Console.ReadLine();
        }
    }
}
