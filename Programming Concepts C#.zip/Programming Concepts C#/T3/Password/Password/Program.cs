﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Password
{
    class Program
    {
        static void Main(string[] args)
        {
            //Emmbeded password
            string Apassword = ("Test");
            
            Console.Write("Enter The Passowrd: ");
            string Inpassword = (Console.ReadLine());

            if (String.Equals(Apassword, Inpassword, StringComparison.Ordinal)) //This compares the string of the actaul password and the password enterd
            { //.Ordinal makes it case sensative
                Console.WriteLine("###########"); //output corrent passwords
                Console.WriteLine("# Welcome #");
                Console.WriteLine("###########");
            }

            else
            {
                Console.WriteLine("-------------------"); //Output inccorect password
                Console.WriteLine("|Incorrectpassword|");
                Console.WriteLine("-------------------");
            }

            Console.ReadLine();
        }

            

        }
    
}
