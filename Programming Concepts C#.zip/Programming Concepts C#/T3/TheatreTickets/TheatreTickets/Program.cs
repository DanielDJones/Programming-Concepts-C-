﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreTickets
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of Adults | "); //Dispaly text
            int AdultN = int.Parse(Console.ReadLine()); //Input 
            Console.Write("Enter the number of Children | ");//Dispaly text
            int KidN = int.Parse(Console.ReadLine());//Input 


            double CostR = 0; //Set up variable 

            double Cost = AdultN * 10.50; // Work out cost of adults 
            Cost = Cost + (KidN * 7.30); //Work out cost for kids  and add it to the total
            //free offers
            double FreeN = KidN / 10; //work out number of free kids 
            FreeN = Math.Floor(FreeN); //roudn down
            Cost = Cost - (FreeN * 10.50); // take discount oif the total
            

           

            //price reduction
            if (Cost >= 100) //total price reduction
            {
                Cost = Cost * 0.9;
                CostR = Cost * 0.1;
            }
            //deliver cost

            Console.Write("Is it going to be collected y/n | "); //dsiplay text
            string collect = (Console.ReadLine()); 

            if (String.Equals(collect, "n", StringComparison.Ordinal)) //Compare the text and input 
            {
                Cost = Cost + 2.34; // Adds the diliver cost to the toatl
            }


            //Output
            Console.WriteLine("===========================");
            Console.WriteLine("");
            Console.WriteLine("Total: £ {0}", Cost);
            Console.WriteLine("");
            Console.WriteLine("===========================");
            Console.WriteLine("Free Adults : {0}", FreeN);
            Console.WriteLine("---------------------------");
            Console.WriteLine("Cost Reduced : £ {0}", CostR);
            Console.WriteLine("---------------------------");
            Console.WriteLine("Collected? : {0}", collect);
            Console.WriteLine("---------------------------");
            Console.ReadLine();



        }
    }
}
