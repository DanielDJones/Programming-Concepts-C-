﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace TestResults
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                StreamReader students = new StreamReader("Names.txt");
                StreamWriter pass = new StreamWriter("Pass.txt", true);
                StreamWriter fail = new StreamWriter("Fail.txt", true);
                String student;
                while((student = students.ReadLine())!=null)
                {
                    Console.WriteLine("Please enter " + student + " % Mark");
                    int mark = int.Parse(Console.ReadLine());

                    if(mark >= 40)
                    {
                        pass.WriteLine(student + " " + mark + "%");
                    }
                    else
                    {
                        fail.WriteLine(student + " " + mark + "%");
                    }
                }
                students.Close();
                pass.Close();
                fail.Close();
            }

            catch(System.IO.FileNotFoundException)
            {
                Console.WriteLine("File not Found");
            }
            catch(System.IO.IOException e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.ReadLine();
        }
    }
}
