﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace EnterStudentNames
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter students = new StreamWriter("Names.txt", true);
                students.Write(txtFirstname.Text + " ");
                students.WriteLine(txtSurname.Text);
                students.Close();
                txtFirstname.Clear();
                txtSurname.Clear();
                txtFirstname.Focus();
            }
            catch (System.IO.FileNotFoundException)
            { Console.WriteLine("File not found"); }
            catch (System.IO.IOException ioe)
            { Console.WriteLine(ioe.ToString()); }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
