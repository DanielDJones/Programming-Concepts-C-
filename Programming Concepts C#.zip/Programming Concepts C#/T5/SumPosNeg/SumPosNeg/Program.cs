﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumPosNeg
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int posCount = 0;
            int negCount = 0;

            for (int count = 1; count <= 10; count++)
            {
                Console.WriteLine("Enter number {0}:", count);
                int Number = int.Parse(Console.ReadLine());

                
                if(Number >= 0)
                {
                    posCount += Number;
                }
                else
                {
                    negCount += Number;
                }
                
            }

            Console.WriteLine(" ");
            Console.WriteLine("Positive total {0}", posCount);
            Console.WriteLine(" ");
            Console.WriteLine("Negative total {0}", negCount);
            Console.WriteLine(" ");
            Console.ReadLine();
        }
    }
}
