﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Width");
            int width = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Height");
            int height = int.Parse(Console.ReadLine());

            for (int count = height; count > 0; count--)
            {
                Console.WriteLine(" ");
                for (int count2 = width; count2 > 0; count2--)
                {
                    Console.Write("*");
                }
                
            }

            Console.ReadLine();
        }
    }
}
