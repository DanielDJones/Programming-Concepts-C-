﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumPosNeg
{
    class Program
    {
        static void Main(string[] args)
        {

            int posCount = 0;
            int negCount = 0;
            int posA = 0;
            int negA = 0;

            for (int count = 1; count <= 10; count++) 
            {
                Console.WriteLine("Enter number {0}:", count);
                int Number = int.Parse(Console.ReadLine()); //converts the number to a int


                if (Number >= 0) //Count postoive 
                {
                    posCount += Number;
                    posA = 1;
                }
                else // check if negative 
                {
                    negCount += Number;
                    negA = 1;
                }

            }
            //output 
            Console.WriteLine(" ");
            Console.WriteLine("Positive total {0}", posCount);
            Console.WriteLine(" ");
            Console.WriteLine("Negative total {0}", negCount);
            Console.WriteLine(" ");
            
            if (posA < 0) //Check if there is posotive numbers 
            {
               int posAv = posCount / posA;
               Console.WriteLine("Avargae +:{0}", posAv);
            }
            else
            {
                Console.WriteLine("No Positive numbers");
            }

            if (negA < 0) //Check if there are negative numbers
            {
                int negAv = negCount / negA;
                Console.WriteLine("Avargae +:{0}", negAv);
            }
            else
            {
                Console.WriteLine("No Negative numbers");
            }
            Console.ReadLine();
        }
    }
}
