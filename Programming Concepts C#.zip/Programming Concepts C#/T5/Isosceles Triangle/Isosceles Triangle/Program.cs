﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Isosceles_Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number of rows"); //Display text
            int rows = int.Parse(Console.ReadLine()); //input number of rows

            int spaces; //set up the int spaces 
            spaces = 0;

            for (int hgt = rows; hgt > 0; hgt--) //set up the loop for the vertical display
            {
                for (int Sspaces = spaces; Sspaces > 0; Sspaces--) //Display spaces before makeing a new row
                {
                    Console.Write(" ");
                }

                

                for (int ast = rows; ast > 0; ast--) //Dispaly * = number fo rows 
                {
                    Console.Write("* ");
                }
                rows = rows - 1; //-1 for row 
                spaces = spaces +1; //Add an extra space 
                Console.WriteLine();
            }


            Console.ReadLine();

        }
    }
}
